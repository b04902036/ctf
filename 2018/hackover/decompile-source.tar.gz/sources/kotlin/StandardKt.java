package kotlin;

@Metadata(bv = {1, 0, 2}, d1 = {"kotlin/StandardKt__StandardKt", "kotlin/StandardKt__SynchronizedKt"}, k = 4, mv = {1, 1, 10}, xi = 1)
public final class StandardKt extends StandardKt__SynchronizedKt {
    private StandardKt() {
    }
}
