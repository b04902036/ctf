package kotlin.jvm.internal;

import kotlin.Metadata;

@Metadata(bv = {1, 0, 2}, d1 = {"\u0000\b\n\u0000\n\u0002\u0010\u0001\n\u0000\u001a\b\u0010\u0000\u001a\u00020\u0001H\u0002¨\u0006\u0002"}, d2 = {"notSupportedError", "", "kotlin-stdlib"}, k = 2, mv = {1, 1, 10})
/* compiled from: localVariableReferences.kt */
public final class LocalVariableReferencesKt {
    private static final Void notSupportedError() {
        throw new UnsupportedOperationException("Not supported for local property reference.");
    }
}
