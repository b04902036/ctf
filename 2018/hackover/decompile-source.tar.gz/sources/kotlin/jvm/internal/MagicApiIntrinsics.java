package kotlin.jvm.internal;

import kotlin.SinceKotlin;

@SinceKotlin(version = "1.2")
public class MagicApiIntrinsics {
    public static <T> T anyMagicApiCall(int i) {
        return null;
    }

    public static <T> T anyMagicApiCall(int i, long j, long j2, Object obj) {
        return null;
    }

    public static <T> T anyMagicApiCall(int i, long j, Object obj) {
        return null;
    }

    public static <T> T anyMagicApiCall(int i, Object obj, Object obj2) {
        return null;
    }

    public static <T> T anyMagicApiCall(int i, Object obj, Object obj2, Object obj3, Object obj4) {
        return null;
    }

    public static <T> T anyMagicApiCall(Object obj) {
        return null;
    }

    public static int intMagicApiCall(int i) {
        return 0;
    }

    public static int intMagicApiCall(int i, long j, long j2, Object obj) {
        return 0;
    }

    public static int intMagicApiCall(int i, long j, Object obj) {
        return 0;
    }

    public static int intMagicApiCall(int i, Object obj, Object obj2) {
        return 0;
    }

    public static int intMagicApiCall(int i, Object obj, Object obj2, Object obj3, Object obj4) {
        return 0;
    }

    public static int intMagicApiCall(Object obj) {
        return 0;
    }

    public static void voidMagicApiCall(int i) {
    }

    public static void voidMagicApiCall(Object obj) {
    }
}
