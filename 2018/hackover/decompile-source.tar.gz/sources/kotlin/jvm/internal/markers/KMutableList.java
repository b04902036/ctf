package kotlin.jvm.internal.markers;

import kotlin.Metadata;

@Metadata(bv = {1, 0, 2}, d1 = {"\u0000\n\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\bf\u0018\u00002\u00020\u0001¨\u0006\u0002"}, d2 = {"Lkotlin/jvm/internal/markers/KMutableList;", "Lkotlin/jvm/internal/markers/KMutableCollection;", "kotlin-stdlib"}, k = 1, mv = {1, 1, 10})
/* compiled from: KMarkers.kt */
public interface KMutableList extends KMutableCollection {
}
