package kotlin.jvm.internal;

final class DefaultConstructorMarker {
    private DefaultConstructorMarker() {
    }
}
