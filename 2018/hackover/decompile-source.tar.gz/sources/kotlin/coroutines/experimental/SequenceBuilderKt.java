package kotlin.coroutines.experimental;

import kotlin.Metadata;

@Metadata(bv = {1, 0, 2}, d1 = {"kotlin/coroutines/experimental/SequenceBuilderKt__SequenceBuilderKt"}, k = 4, mv = {1, 1, 10}, xi = 1)
/* compiled from: SequenceBuilder.kt */
public final class SequenceBuilderKt extends SequenceBuilderKt__SequenceBuilderKt {
    private SequenceBuilderKt() {
    }
}
