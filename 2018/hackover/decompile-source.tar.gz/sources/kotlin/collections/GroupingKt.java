package kotlin.collections;

import kotlin.Metadata;

@Metadata(bv = {1, 0, 2}, d1 = {"kotlin/collections/GroupingKt__GroupingJVMKt", "kotlin/collections/GroupingKt__GroupingKt"}, k = 4, mv = {1, 1, 10}, xi = 1)
public final class GroupingKt extends GroupingKt__GroupingKt {
    private GroupingKt() {
    }
}
