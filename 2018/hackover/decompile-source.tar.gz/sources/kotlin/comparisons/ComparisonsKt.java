package kotlin.comparisons;

import kotlin.Metadata;

@Metadata(bv = {1, 0, 2}, d1 = {"kotlin/comparisons/ComparisonsKt__ComparisonsKt", "kotlin/comparisons/ComparisonsKt___ComparisonsJvmKt", "kotlin/comparisons/ComparisonsKt___ComparisonsKt"}, k = 4, mv = {1, 1, 10}, xi = 1)
public final class ComparisonsKt extends ComparisonsKt___ComparisonsKt {
    private ComparisonsKt() {
    }
}
