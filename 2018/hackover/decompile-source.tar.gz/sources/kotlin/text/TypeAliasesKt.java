package kotlin.text;

import kotlin.Metadata;
import kotlin.SinceKotlin;

@Metadata(bv = {1, 0, 2}, d1 = {"\u0000\u0014\n\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0000*\u001a\b\u0007\u0010\u0000\"\u00020\u00012\u00020\u0001B\f\b\u0002\u0012\b\b\u0003\u0012\u0004\b\b(\u0004*\u001a\b\u0007\u0010\u0005\"\u00020\u00062\u00020\u0006B\f\b\u0002\u0012\b\b\u0003\u0012\u0004\b\b(\u0004¨\u0006\u0007"}, d2 = {"Appendable", "Ljava/lang/Appendable;", "Lkotlin/SinceKotlin;", "version", "1.1", "StringBuilder", "Ljava/lang/StringBuilder;", "kotlin-stdlib"}, k = 2, mv = {1, 1, 10})
/* compiled from: TypeAliases.kt */
public final class TypeAliasesKt {
    @SinceKotlin(version = "1.1")
    public static /* synthetic */ void Appendable$annotations() {
    }

    @SinceKotlin(version = "1.1")
    public static /* synthetic */ void StringBuilder$annotations() {
    }
}
