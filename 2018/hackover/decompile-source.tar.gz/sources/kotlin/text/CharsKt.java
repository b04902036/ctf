package kotlin.text;

import kotlin.Metadata;

@Metadata(bv = {1, 0, 2}, d1 = {"kotlin/text/CharsKt__CharJVMKt", "kotlin/text/CharsKt__CharKt"}, k = 4, mv = {1, 1, 10}, xi = 1)
public final class CharsKt extends CharsKt__CharKt {
    private CharsKt() {
    }
}
