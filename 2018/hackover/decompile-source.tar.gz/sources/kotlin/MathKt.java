package kotlin;

@Metadata(bv = {1, 0, 2}, d1 = {"kotlin/MathKt__BigDecimalsKt", "kotlin/MathKt__BigIntegersKt", "kotlin/MathKt__NumbersKt"}, k = 4, mv = {1, 1, 10}, xi = 1)
public final class MathKt extends MathKt__NumbersKt {
    private MathKt() {
    }
}
