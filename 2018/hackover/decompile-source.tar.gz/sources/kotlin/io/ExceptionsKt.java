package kotlin.io;

import java.io.File;
import kotlin.Metadata;
import kotlin.jvm.internal.Intrinsics;

@Metadata(bv = {1, 0, 2}, d1 = {"\u0000\u0010\n\u0000\n\u0002\u0010\u000e\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\u001a$\u0010\u0000\u001a\u00020\u00012\u0006\u0010\u0002\u001a\u00020\u00032\b\u0010\u0004\u001a\u0004\u0018\u00010\u00032\b\u0010\u0005\u001a\u0004\u0018\u00010\u0001H\u0002¨\u0006\u0006"}, d2 = {"constructMessage", "", "file", "Ljava/io/File;", "other", "reason", "kotlin-stdlib"}, k = 2, mv = {1, 1, 10})
/* compiled from: Exceptions.kt */
public final class ExceptionsKt {
    private static final String constructMessage(File file, File file2, String str) {
        StringBuilder stringBuilder;
        StringBuilder stringBuilder2 = new StringBuilder(file.toString());
        if (file2 != null) {
            stringBuilder = new StringBuilder();
            stringBuilder.append(" -> ");
            stringBuilder.append(file2);
            stringBuilder2.append(stringBuilder.toString());
        }
        if (str != null) {
            stringBuilder = new StringBuilder();
            stringBuilder.append(": ");
            stringBuilder.append(str);
            stringBuilder2.append(stringBuilder.toString());
        }
        String stringBuilder3 = stringBuilder2.toString();
        Intrinsics.checkExpressionValueIsNotNull(stringBuilder3, "sb.toString()");
        return stringBuilder3;
    }
}
