package kotlin.math;

import kotlin.Metadata;

@Metadata(bv = {1, 0, 2}, d1 = {"\u0000\n\n\u0000\n\u0002\u0010\u0006\n\u0002\b\u0005\"\u0014\u0010\u0000\u001a\u00020\u00018\u0006XT¢\u0006\u0006\u0012\u0004\b\u0002\u0010\u0003\"\u0014\u0010\u0004\u001a\u00020\u00018\u0006XT¢\u0006\u0006\u0012\u0004\b\u0005\u0010\u0003¨\u0006\u0006"}, d2 = {"E", "", "E$annotations", "()V", "PI", "PI$annotations", "kotlin-stdlib"}, k = 5, mv = {1, 1, 10}, xi = 1, xs = "kotlin/math/MathKt")
/* compiled from: MathH.kt */
class MathKt__MathHKt {
}
